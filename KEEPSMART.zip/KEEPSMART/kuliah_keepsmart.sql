-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Nov 27, 2024 at 11:45 AM
-- Server version: 8.0.30
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kuliah_keepsmart`
--

-- --------------------------------------------------------

--
-- Table structure for table `arus_uang`
--

CREATE TABLE `arus_uang` (
  `id_arus` int NOT NULL,
  `id_user` int NOT NULL,
  `id_semester` int NOT NULL,
  `id_kategori` int NOT NULL,
  `jenis` varchar(12) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `keperluan` varchar(30) NOT NULL,
  `tanggal` date NOT NULL,
  `nominal` int NOT NULL,
  `bukti` varchar(60) DEFAULT NULL,
  `catatan` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `arus_uang`
--

INSERT INTO `arus_uang` (`id_arus`, `id_user`, `id_semester`, `id_kategori`, `jenis`, `keperluan`, `tanggal`, `nominal`, `bukti`, `catatan`, `created_at`, `updated_at`) VALUES
(1, 9, 3, 7, 'pemasukan', 'Dana KIP-K Semester 1', '2024-11-16', 75000, '673856949a16b.png', 'asas', '2024-11-16 08:23:48', '2024-11-23 14:39:14'),
(2, 9, 3, 8, 'pengeluaran', 'membeli hvs', '2024-11-16', 10000, '673856cbdb8e2.jpg', 'sas', '2024-11-16 08:24:43', '2024-11-24 11:06:36'),
(3, 10, 3, 11, 'pemasukan', 'Dana KIP-K Semester 1', '2024-11-01', 2000000, '6746133656e1f.jpg', 'a', '2024-11-26 18:28:06', '2024-11-26 18:28:06'),
(13, 9, 3, 7, 'pengeluaran', 'coba lahh', '2024-11-27', 20000, '6746954b8c990.jpg', 'asas', '2024-11-27 03:43:07', '2024-11-27 03:43:44'),
(14, 14, 3, 18, 'pemasukan', 'Dana KIP-K Semester 1', '2024-11-27', 75000, '6747002b1ac45.jpg', 'Dana Pendidikan KIP-K 2024', '2024-11-27 11:17:04', '2024-11-27 11:19:07'),
(15, 14, 3, 18, 'pengeluaran', 'membeli hvs', '2024-11-27', 10000, '6746ffe02f11e.jpg', 'asas', '2024-11-27 11:17:52', '2024-11-27 11:17:52');

-- --------------------------------------------------------

--
-- Table structure for table `kategori`
--

CREATE TABLE `kategori` (
  `id_kategori` int NOT NULL,
  `id_user` int NOT NULL,
  `nama_kategori` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `kategori`
--

INSERT INTO `kategori` (`id_kategori`, `id_user`, `nama_kategori`) VALUES
(7, 9, 'Pendidikan'),
(8, 9, 'Sial'),
(9, 9, 'Makanan'),
(11, 10, 'Pendidikan'),
(13, 10, 'Sial'),
(14, 9, 'Coba '),
(17, 13, 'Pendidikan'),
(18, 14, 'Pendidikan'),
(19, 14, 'Bensin');

-- --------------------------------------------------------

--
-- Table structure for table `semester`
--

CREATE TABLE `semester` (
  `id_semester` int NOT NULL,
  `semester` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `semester`
--

INSERT INTO `semester` (`id_semester`, `semester`) VALUES
(3, 1),
(4, 2),
(5, 3),
(6, 4),
(7, 5),
(8, 6),
(9, 7),
(10, 8);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id_user` int NOT NULL,
  `username` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `no_hp` varchar(15) NOT NULL,
  `foto` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id_user`, `username`, `email`, `password`, `no_hp`, `foto`) VALUES
(9, 'Deni Andriansyah ', 'andriansyahdeni2004@gmail.com', '$2y$10$nF6VeSul2.iptwuydbIstuekiWEUstfFSmTMr2dmoWTZ7hVKWvhmG', '085604667864', '6746de0677a3f.png'),
(10, 'Baruuu', 'guru1@gmail.com', '$2y$10$ZBq6.25UWqx.XD0nbRqo2u4vgmL0K/lyatnk1xkNKGlDekNgcF8oC', '085604667864', '67460c0482038.jpeg'),
(13, 'admin', 'admin@gmail.com', '$2y$10$tktGOIFlWMVwFyK3q.2Swub6RMajxsDk4bbKZVVpnaFyRiU43kpXC', '123', '6746e049928cb.jpg'),
(14, 'Deni Andriansyah', 'deniandriansyah@gmail.com', '$2y$10$6o0iWmpeFBaGfhIH8uZi4.5PR6RSyPIXmMPk97RRt8y5kmRCLLOja', '1234', '6746fda222afa.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `arus_uang`
--
ALTER TABLE `arus_uang`
  ADD PRIMARY KEY (`id_arus`),
  ADD KEY `id_kategori` (`id_kategori`),
  ADD KEY `id_user` (`id_user`),
  ADD KEY `id_semester` (`id_semester`);

--
-- Indexes for table `kategori`
--
ALTER TABLE `kategori`
  ADD PRIMARY KEY (`id_kategori`),
  ADD KEY `id_user` (`id_user`);

--
-- Indexes for table `semester`
--
ALTER TABLE `semester`
  ADD PRIMARY KEY (`id_semester`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `arus_uang`
--
ALTER TABLE `arus_uang`
  MODIFY `id_arus` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `kategori`
--
ALTER TABLE `kategori`
  MODIFY `id_kategori` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `semester`
--
ALTER TABLE `semester`
  MODIFY `id_semester` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id_user` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `arus_uang`
--
ALTER TABLE `arus_uang`
  ADD CONSTRAINT `arus_uang_ibfk_3` FOREIGN KEY (`id_semester`) REFERENCES `semester` (`id_semester`),
  ADD CONSTRAINT `arus_uang_ibfk_4` FOREIGN KEY (`id_kategori`) REFERENCES `kategori` (`id_kategori`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `arus_uang_ibfk_5` FOREIGN KEY (`id_user`) REFERENCES `user` (`id_user`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `kategori`
--
ALTER TABLE `kategori`
  ADD CONSTRAINT `kategori_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `user` (`id_user`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
