<?php
include '../../koneksi.php';

if (isset($_POST['input'])) {
    $input = mysqli_real_escape_string($host, $_POST['input']); // Keamanan input

    $query = "
        SELECT 
            arus_uang.id_arus,
            semester.semester AS semester,
            kategori.nama_kategori AS kategori,
            arus_uang.jenis,
            arus_uang.keperluan,
            arus_uang.tanggal,
            arus_uang.nominal,
            arus_uang.catatan
        FROM arus_uang
        LEFT JOIN kategori ON arus_uang.id_kategori = kategori.id_kategori
        LEFT JOIN semester ON arus_uang.id_semester = semester.id_semester
        WHERE 
            arus_uang.keperluan LIKE '{$input}%' OR 
            kategori.nama_kategori LIKE '{$input}%' OR 
            semester.semester LIKE '{$input}%' OR 
            arus_uang.jenis LIKE '{$input}%' OR 
            arus_uang.tanggal LIKE '{$input}%' OR 
            arus_uang.nominal LIKE '{$input}%' OR 
            arus_uang.catatan LIKE '{$input}%'
    ";

    $result = mysqli_query($host, $query);

    if ($result && mysqli_num_rows($result) > 0) { ?>
        <table class="table table-bordered table-striped table-hover mt-4">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Semester</th>
                    <th>Kategori</th>
                    <th>Jenis</th>
                    <th>Keperluan</th>
                    <th>Tanggal</th>
                    <th>Nominal</th>
                    <th>Catatan</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $no = 1;
                while ($row = mysqli_fetch_assoc($result)) {
                    ?>
                    <tr>
                        <td><?php echo $no++; ?></td>
                        <td><?php echo htmlspecialchars($row['semester']); ?></td>
                        <td><?php echo htmlspecialchars($row['kategori']); ?></td>
                        <td><?php echo htmlspecialchars($row['jenis']); ?></td>
                        <td><?php echo htmlspecialchars($row['keperluan']); ?></td>
                        <td><?php echo htmlspecialchars($row['tanggal']); ?></td>
                        <td><?php echo number_format($row['nominal'], 0, ',', '.'); ?></td>
                        <td><?php echo htmlspecialchars($row['catatan']); ?></td>
                    </tr>
                    <?php
                }
                ?>
            </tbody>
        </table>
    <?php
    } else {
        echo "<h6 class='text-danger text-center mt-3'>Data tidak ditemukan</h6>";
    }
}
?>
