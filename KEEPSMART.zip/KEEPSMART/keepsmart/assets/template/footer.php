        </div>
    </section>


    <script src="scrip  t.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-pzjw8f+ua7Kw1TIq0fgz6Y1qCkFp7ykV7pnzGcVpmbxaWZx3vppw95h61b2BxAXx" crossorigin="anonymous"></script>
    <script>
        // logout
        // Fungsi untuk menampilkan pesan konfirmasi
        // function confirmLogout(event) {
        //     event.preventDefault(); // Mencegah aksi default (logout langsung)
        //     const userConfirmed = confirm("Apakah Anda yakin ingin logout?");
        //     if (userConfirmed) {
        //         // Arahkan ke halaman logout jika pengguna mengonfirmasi
        //         window.location.href = event.target.href;
        //     }
        // }
        
        // modal
        const body = document.querySelector("body"),
            modeToggle = body.querySelector(".mode-toggle");
            sidebar = body.querySelector("nav");
            sidebarToggle = body.querySelector(".sidebar-toggle");

        let getMode = localStorage.getItem("mode");
        if(getMode && getMode ==="dark"){
            body.classList.toggle("dark");
        }

        let getStatus = localStorage.getItem("status");
        if(getStatus && getStatus ==="close"){
            sidebar.classList.toggle("close");
        }

        modeToggle.addEventListener("click", () =>{
            body.classList.toggle("dark");
            if(body.classList.contains("dark")){
                localStorage.setItem("mode", "dark");
            }else{
                localStorage.setItem("mode", "light");
            }
        });

        sidebarToggle.addEventListener("click", () => {
            sidebar.classList.toggle("close");
            if(sidebar.classList.contains("close")){
                localStorage.setItem("status", "close");
            }else{
                localStorage.setItem("status", "open");
            }
        })
    </script>

<script>
    document.getElementById('logout').addEventListener('click', function(e) {
        e.preventDefault(); // Prevent the default logout behavior

        // Show SweetAlert confirmation dialog
        Swal.fire({
            title: 'Sign Out',
            text: 'Apakah kamu yakin ingin keluar?',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Ya, saya ingin keluar!',
            cancelButtonText: 'Tidak, batalkan!',
            reverseButtons: true
        }).then((result) => {
            if (result.isConfirmed) {
                // Redirect to the logout page if confirmed
                window.location.href = '../../../index.php';
            }
        });
    });
</script>

<!-- data tabel -->
<script>
    $(document).ready(function() {
        $('#example').DataTable();
    });
</script>

<!-- Live Search -->
<script type="text/javascript">
    $(document).ready(function(){
        $("#live_search").keyup(function(){
            var input = $(this).val();
            // alert(input);

            if(input !=""){
                $.ajax({
                    url: "livesearch.php",
                    method:"POST",
                    data: {input:input},

                    success:function(data){
                        $("#searchresult").html(data);
                    }
                });
            } else{
                $("#searchresult").css("display", "none");
            }
        });
    });
</script>


</body>
</html>