<?php

    $host = mysqli_connect("localhost", "root", "", "kuliah_keepsmart");