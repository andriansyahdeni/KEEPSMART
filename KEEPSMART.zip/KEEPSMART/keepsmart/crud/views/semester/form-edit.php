<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Semester</title>
</head>
<body>

    <?php
        include '../../../koneksi.php';
        $id_semester = $_GET['id_semester'];

        $query   = "SELECT * FROM semester WHERE id_semester = $id_semester";

        $execute = mysqli_query($host, $query);
        $see     = mysqli_fetch_assoc($execute);
    ?>
    
    <h1>Form Edit Semester</h1>
    <a href="data.php">Kembali</a>
    <!-- link untuk kembali ke data.php -->

    <form action="../../controller/Semester.php?id_semester=<?= $id_semester ?>" method="POST">
        <label>Nama</label><br>
        <input type="text" name="semester" value="<?php echo $see['semester'] ?>"><br>

        <button name="update">Edit</button>
    </form>

</body>
</html>