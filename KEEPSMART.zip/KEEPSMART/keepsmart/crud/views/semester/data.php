<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Semester</title>
</head>
<body>
    <h1>Data Semester</h1>
    <a href="form.php">Tambah data</a>

    <table border="1">
        <thead>
            <tr>
                <th>Semester</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php
                include '../../../koneksi.php';

                $query = "SELECT * FROM semester";
                $execute = mysqli_query($host, $query);

                $no = 1;
                while ($see = mysqli_fetch_assoc($execute)) {
            ?>
            <tr>
                <td><?php echo $see['semester'] ?></td>
                <td>
                    <a href="form-edit.php?id_semester=<?= $see['id_semester'] ?>">Edit</a>
                    <a href="../../controller/Semester.php?delete=<?= $see['id_semester'] ?>">Delete</a>
                </td>
            </tr>
            <?php } ?>
        </tbody>
    </table>
</body>
</html>