<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Semester</title>
</head>
<body>
    
    <h1>Form Tambah Semester</h1>
    <a href="data.php">Kembali</a>
    <!-- link untuk kembali ke data.php -->

    <form action="../../controller/Semester.php" method="POST">
        <label>Nama</label><br>
        <input type="text" name="semester">

        <button name="tambah">Kirim</button>
    </form>

</body>
</html>