<?php include('../../../assets/template/header.php'); ?>
<body class="body">

    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card shadow">
                    <div class="card-body">
                        <h3 class="card-title text-center">Edit Kategori</h3>
                        <hr>

                        <?php
                            include '../../../koneksi.php';
                            $id_kategori = $_GET['id_kategori'];

                            // Query untuk mendapatkan data kategori berdasarkan id
                            $query = "SELECT * FROM kategori WHERE id_kategori = $id_kategori";
                            $execute = mysqli_query($host, $query);
                            $see = mysqli_fetch_assoc($execute);
                        ?>

                        <form action="../../controller/Category.php?id_kategori=<?= $id_kategori ?>" method="POST">
                            <!-- Input Nama Kategori -->
                            <div class="mb-3">
                                <label for="nama_kategori" class="form-label">Nama Kategori</label>
                                <input type="text" id="nama_kategori" name="nama_kategori" value="<?= htmlspecialchars($see['nama_kategori']) ?>" class="form-control" required>
                            </div>

                            <!-- Submit Button -->
                            <div class="d-flex">
                                <button type="submit" name="update" class="btn btn-primary">Update</button>
                                <a href="data.php" class="btn btn-link me-2">Kembali</a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

</body>
<?php include('../../../assets/template/footer.php'); ?>
