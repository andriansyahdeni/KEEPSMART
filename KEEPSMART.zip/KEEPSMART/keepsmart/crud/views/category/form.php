<?php include('../../../assets/template/header.php'); ?>
<body class="body">

    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card shadow">
                    <div class="card-body">
                        <h3 class="card-title text-center">Tambah Kategori</h3>
                        <hr>

                        <form action="../../controller/Category.php" method="POST">
                            <!-- Input Nama Kategori -->
                            <div class="mb-3">
                                <label for="nama_kategori" class="form-label">Nama Kategori</label>
                                <input type="text" id="nama_kategori" name="nama_kategori" class="form-control" required>
                            </div>

                            <!-- Submit Button -->
                            <div class="d-flex">
                                <button type="submit" name="tambah" class="btn btn-primary">Tambah</button>
                                <a href="data.php" class="btn btn-link me-2">Kembali</a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

</body>
<?php include('../../../assets/template/footer.php'); ?>
