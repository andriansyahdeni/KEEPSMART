<?php include('../../../assets/template/header.php'); ?>

<?php
if (isset($_SESSION['status'])) {
    $status = $_SESSION['status'];
    echo "<script>
        document.addEventListener('DOMContentLoaded', function() {
            Swal.fire({
                icon: '{$status['type']}',
                title: '{$status['message']}',
                showConfirmButton: false,
                timer: 1500
            });
        });
    </script>";
    unset($_SESSION['status']);
}
?>

    <style>
        table th {
            text-align: center;
        }

        .judul-container {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .judul-container h2 {
            margin: 0;
        }

        .judul-container .btn {
            margin-left: 10px;
        }

        .table-responsive {
            overflow-x: auto;
        }
    </style>
</head>
<body>
    <div class="container-fluid mt-5">
        <?php
            include '../../../koneksi.php';
            // session_start();

            // Cek apakah id_user ada dalam session
            if (!isset($_SESSION['id_user'])) {
                // Redirect jika session id_user tidak ada
                header("Location: ../authentication/login.php");
                exit();
            }

            $id_user = $_SESSION['id_user']; // Ambil id_user dari session
        ?>

        <div class="judul-container mt-2 mb-3">
            <div class="d-flex align-items-center">
                <h2 class="ml-3">Data Kategori</h2>
            </div>
            <!-- Tombol Tambah Data -->
            <div>
                <a class="btn btn-success" href="form.php" role="button" style="text-decoration:none;">
                    <i class="fa-solid fa-plus"></i>
                </a>
            </div>
        </div>

        <!-- Tabel Data Kategori -->
        <div class="card shadow mt-3">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered table-striped table-hover">
                        <thead>
                            <tr class="table-primary">
                                <th scope="col">No</th>
                                <th scope="col">Nama Kategori</th>
                                <th scope="col">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                $query = "SELECT * FROM kategori WHERE id_user = $id_user";
                                $execute = mysqli_query($host, $query);

                                if (mysqli_num_rows($execute) > 0) {
                                    $no = 1;
                                    while ($see = mysqli_fetch_assoc($execute)) {
                            ?>
                            <tr>
                                <td align="center"><?= $no++ ?></td>
                                <td><?= htmlspecialchars($see['nama_kategori']) ?></td>
                                <td align="center">
                                    <a href="form-edit.php?id_kategori=<?= $see['id_kategori'] ?>" class="btn btn-warning btn-sm">
                                        <i class="fa-regular fa-pen-to-square"></i>
                                    </a>
                                    <a href="#" onclick="confirmDelete(<?= $see['id_kategori']; ?>)" class="btn btn-danger btn-sm">
                                        <i class="fa-solid fa-trash"></i>
                                    </a>
                                </td>
                            </tr>
                            <?php
                                    }
                                } else {
                            ?>
                            <tr>
                                <td colspan="3" align="center">Tidak ada data kategori.</td>
                            </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

<script>
    function confirmDelete(id) {
        Swal.fire({
            title: 'Apakah Anda yakin?',
            text: "Data yang dihapus tidak dapat dikembalikan!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#d33',
            cancelButtonColor: '#3085d6',
            confirmButtonText: 'Hapus',
            cancelButtonText: 'Batal'
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = `../../controller/Category.php?delete=${id}`;
            }
        });
    }
</script>


<?php include('../../../assets/template/footer.php'); ?>
