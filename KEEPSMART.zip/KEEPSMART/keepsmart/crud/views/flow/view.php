<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Data Arus</title>
    <style>
        /* Modal styles */
        .modal {
            display: none;
            position: fixed;
            z-index: 1;
            padding-top: 60px;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgb(0,0,0);
            background-color: rgba(0,0,0,0.4);
        }

        .modal-content {
            margin: auto;
            display: block;
            width: 80%;
            max-width: 700px;
        }

        .close {
            position: absolute;
            top: 15px;
            right: 35px;
            color: #fff;
            font-size: 40px;
            font-weight: bold;
            cursor: pointer;
        }
    </style>
</head>
<body>
    
    <h1>Form Edit Data Arus</h1>
    <a href="data.php">Kembali</a>

    <?php
        include '../../../koneksi.php';
        $id_arus = $_GET['id_arus'];

        // Query untuk mendapatkan data arus berdasarkan id
        $query   = "SELECT * FROM arus_uang WHERE id_arus = $id_arus";
        $execute = mysqli_query($host, $query);
        $see = mysqli_fetch_assoc($execute);
    ?>

    <form action="../../controller/Flow.php?id_arus=<?= $id_arus ?>" method="POST" enctype="multipart/form-data">
        
        <!-- ID User -->
        <input type="hidden" name="id_user" value="1" required> <br>

        <!-- Kategori -->
        <label>Kategori</label><br>
        <select name="id_kategori" required>
            <option value="">Pilih Kategori</option>
            <?php
            // Ambil semua kategori dari database
            $kategori_query = "SELECT * FROM kategori";
            $kategori_result = mysqli_query($host, $kategori_query);

            while ($kategori = mysqli_fetch_assoc($kategori_result)) {
                $selected = ($see['id_kategori'] == $kategori['id_kategori']) ? 'selected' : '';
                echo "<option value='{$kategori['id_kategori']}' $selected>{$kategori['nama_kategori']}</option>";
            }
            ?>
        </select> <br>

        <!-- Jenis (masuk/keluar) -->
        <label>Jenis</label><br>
        <select name="jenis" required>
            <option value="pengeluaran" <?php echo ($see['jenis'] == 'pengeluaran') ? 'selected' : ''; ?>>Pengeluaran</option>
            <option value="pemasukan" <?php echo ($see['jenis'] == 'pemasukan') ? 'selected' : ''; ?>>Pemasukan</option>
        </select> <br>

        <!-- Keperluan -->
        <label>Keperluan</label><br>
        <input type="text" name="keperluan" value="<?php echo $see['keperluan']; ?>" required> <br>

        <!-- Tanggal -->
        <label>Tanggal</label><br>
        <input type="date" name="tanggal" value="<?php echo $see['tanggal']; ?>" required> <br>

        
        <!-- Semester -->
        <label>Semester</label><br>
        <select name="id_semester" required>
            <option value="">Pilih Semester</option>
            <?php
            // Ambil semua kategori dari database
            $query_semester = "SELECT * FROM semester";
            $result_semester = mysqli_query($host, $query_semester);

            while ($semester = mysqli_fetch_assoc($result_semester)) {
                $selected = ($see['id_semester'] == $semester['id_semester']) ? 'selected' : '';
                echo "<option value='{$semester['id_semester']}' $selected>{$semester['semester']}</option>";
            }
            ?>
        </select> <br>

        <!-- Nominal -->
        <label>Nominal</label><br>
        <input type="number" name="nominal" value="<?php echo $see['nominal']; ?>" required> <br>

        <!-- Foto Bukti -->
        <label>Foto Bukti</label><br>
        <?php if (!empty($see['bukti'])): ?>
            <!-- Tampilkan foto bukti yang ada -->
            <img src="../../../assets/uploads/bukti/<?php echo $see['bukti']; ?>" alt="Foto Bukti" width="100" height="auto" onclick="openModal('<?php echo '../../../assets/uploads/bukti/' . $see['bukti']; ?>')">
        <?php else: ?>
            <p>Tidak ada foto bukti sebelumnya.</p>
        <?php endif; ?>

        <!-- Unggah Foto Baru -->
        <label>Unggah Foto Baru (Opsional)</label><br>
        <input type="file" name="bukti" id="bukti" onchange="previewImage(event)"> <br>

        <!-- Tempat Preview Foto Baru -->
        <img id="preview" src="#" alt="Preview Foto" style="display:none; width:100px; height:auto; margin-top:10px;"><br>

        <!-- Catatan -->
        <label>Catatan</label><br>
        <textarea name="catatan" rows="4"><?php echo $see['catatan']; ?></textarea> <br>

        <!-- Submit Button -->
        <button type="submit" name="update">Update Data Arus</button>
    </form>

    <!-- Modal untuk menampilkan foto bukti -->
    <div id="myModal" class="modal">
        <span class="close" onclick="closeModal()">&times;</span>
        <img class="modal-content" id="img01">
    </div>

    <script>
        // Fungsi untuk membuka modal dan menampilkan gambar
        function openModal(imageSrc) {
            var modal = document.getElementById("myModal");
            var img = document.getElementById("img01");
            modal.style.display = "block";
            img.src = imageSrc;
        }

        // Fungsi untuk menutup modal
        function closeModal() {
            var modal = document.getElementById("myModal");
            modal.style.display = "none";
        }

        // Fungsi untuk preview gambar baru yang diunggah
        function previewImage(event) {
            var reader = new FileReader();
            reader.onload = function() {
                var output = document.getElementById('preview');
                output.src = reader.result;  // Set source gambar menjadi hasil file yang dipilih
                output.style.display = 'block';  // Menampilkan elemen gambar
            };
            reader.readAsDataURL(event.target.files[0]);  // Membaca file yang dipilih
        }
    </script>

</body>
</html>
