<?php
// session_start(); // Memulai sesi untuk mendapatkan id_user yang masuk

include('../../../assets/template/header.php'); 

if (isset($_SESSION['status'])) {
    $status = $_SESSION['status'];
    echo "<script>
        document.addEventListener('DOMContentLoaded', function() {
            Swal.fire({
                icon: '{$status['type']}',
                title: '{$status['message']}',
                showConfirmButton: false,
                timer: 1500
            });
        });
    </script>";
    unset($_SESSION['status']);
}


?>


<style>
    table th {
        text-align: center;
    }

    .judul-container {
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    .judul-container h2 {
        margin: 0;
    }

    .judul-container .btn {
        margin-left: 10px;
    }

    .table-responsive {
        overflow-x: auto;
    }
</style>

<div class="container-fluid mt-5">
    <?php
    include '../../../koneksi.php';

    // Ambil id_semester dari parameter URL
    $id_semester = isset($_GET['id_semester']) ? intval($_GET['id_semester']) : null;

    // Validasi id_semester
    if (!$id_semester) {
        echo "<div class='alert alert-danger'>Semester tidak valid atau tidak dipilih.</div>";
        exit;
    }

    // Pastikan user sudah login dengan mengecek id_user dalam session
    if (!isset($_SESSION['id_user'])) {
        echo "<div class='alert alert-danger'>Anda belum login.</div>";
        exit;
    }

    $id_user = $_SESSION['id_user']; // Ambil id_user dari session

    // Ambil data semester berdasarkan id_semester
    $semester_query = "SELECT * FROM semester WHERE id_semester = $id_semester";
    $semester_result = mysqli_query($host, $semester_query);

    if (!$semester_result) {
        die("<div class='alert alert-danger'>Error pada query: " . mysqli_error($host) . "</div>");
    }

    $semester = mysqli_fetch_assoc($semester_result);

    if (!$semester) {
        echo "<div class='alert alert-danger'>Data semester tidak ditemukan.</div>";
        exit;
    }
    ?>

    <div class="judul-container mt-2 mb-3">
        <div class="d-flex align-items-center">
            <h2 class="ml-3">Data Arus Uang Semester <?= htmlspecialchars($semester['semester']) ?></h2>
        </div>

        <!-- Tombol Tambah Data -->
        <div>
            <a class="btn btn-success" href="form.php?id_semester=<?= $id_semester ?>" role="button" style="text-decoration:none;">
                <i class="fa-solid fa-plus"></i>
            </a>
        </div>
    </div>

    <!-- Tabel Data Arus Uang -->
    <div class="card shadow mt-3">
        <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered table-striped table-hover" id="example">
                <thead>
                    <tr class="table-primary">
                        <th scope="col">No</th>
                        <th scope="col">Tanggal</th>
                        <th scope="col">Jenis</th>
                        <th scope="col">Keperluan</th>
                        <th scope="col">Nominal</th>
                        <th scope="col">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    // Ambil data arus_uang berdasarkan id_semester dan id_user
                    $query = "SELECT * FROM arus_uang WHERE id_semester = $id_semester AND id_user = $id_user ORDER BY tanggal ASC";
                    $jalankan = mysqli_query($host, $query);

                    if (!$jalankan) {
                        die("<div class='alert alert-danger'>Query error: " . mysqli_error($host) . "</div>");
                    }

                    if (mysqli_num_rows($jalankan) > 0) {
                        $no = 1;
                        while ($see = mysqli_fetch_assoc($jalankan)) {
                            ?>
                            <tr>
                                <td align="center"><?= $no++ ?></td>
                                <td><?php echo date('d F Y', strtotime($see['tanggal'])) ?> </td>
                                <td><?= htmlspecialchars($see['jenis']) ?></td>
                                <td><?= htmlspecialchars($see['keperluan']) ?></td>
                                <td align="right"><?= number_format($see['nominal'], 0, ',', '.') ?></td>
                                <td>
                                    <a href="form-edit.php?id_arus=<?= $see['id_arus'] ?>" class="btn btn-warning btn-sm">
                                        <i class="fa-regular fa-pen-to-square"></i>
                                    </a>
                                    <a href="javascript:void(0);" class="btn btn-danger btn-sm" onclick="deleteData(<?= $see['id_arus']; ?>)">
                                        <i class="fa-solid fa-trash"></i>
                                    </a>
                                </td>
                            </tr>
                        <?php }
                    } else { ?>
                        <tr>
                            <td colspan="6" align="center">Tidak ada data untuk semester ini.</td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>

        </div>
    </div>

</div>

<script type="text/javascript">
    function deleteData(id_arus) {
        // Menampilkan SweetAlert konfirmasi
        Swal.fire({
            title: 'Apakah Anda yakin?',
            text: 'Data ini akan dihapus secara permanen!',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Hapus',
            cancelButtonText: 'Batal'
        }).then((result) => {
            if (result.isConfirmed) {
                // Jika konfirmasi, redirect ke URL penghapusan dengan id_arus
                window.location.href = '../../controller/Flow.php?delete=' + id_arus;
            }
        });
    }
</script>


<?php include('../../../assets/template/footer.php'); ?>
