<?php include('../../../assets/template/header.php'); ?>
<body class="body">

    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-11">
                <div class="card shadow">
                    <div class="card-body">
                        <h3 class="card-title text-center">Edit Data Arus</h3>
                        <hr>

                        <?php
                            include '../../../koneksi.php';
                            $id_arus = $_GET['id_arus'];
                            $id_semester = isset($_GET['id_semester']) ? intval($_GET['id_semester']) : null;

                            // Query untuk mendapatkan data arus berdasarkan id
                            $query = "SELECT * FROM arus_uang WHERE id_arus = $id_arus";
                            $execute = mysqli_query($host, $query);
                            $see = mysqli_fetch_assoc($execute);
                        ?>

                        <form action="../../controller/Flow.php?id_arus=<?= $id_arus ?>" method="POST" enctype="multipart/form-data">

                            <!-- ID User -->
                            <input type="hidden" name="id_user" value="<?php echo $_SESSION['id_user']; ?>" required>

                            <!-- Grid Row for Kategori & Jenis -->
                            <div class="row">
                                <!-- Kategori -->
                                <div class="col-md-6 mb-3">
                                    <label for="id_kategori">Kategori</label>
                                    <select name="id_kategori" id="id_kategori" class="form-control" required>
                                        <option value="" disabled>Pilih Kategori</option>
                                        <?php
                                        // Ambil semua kategori dari database
                                        $kategori_query = "SELECT * FROM kategori WHERE id_user = '{$_SESSION['id_user']}'";
                                        $kategori_result = mysqli_query($host, $kategori_query);

                                        while ($kategori = mysqli_fetch_assoc($kategori_result)) {
                                            $selected = ($see['id_kategori'] == $kategori['id_kategori']) ? 'selected' : '';
                                            echo "<option value='{$kategori['id_kategori']}' $selected>{$kategori['nama_kategori']}</option>";
                                        }
                                        ?>
                                    </select>
                                </div>

                                <!-- Jenis (masuk/keluar) -->
                                <div class="col-md-6 mb-3">
                                    <label for="jenis">Jenis</label>
                                    <select name="jenis" id="jenis" class="form-control" required>
                                        <option value="pengeluaran" <?php echo ($see['jenis'] == 'pengeluaran') ? 'selected' : ''; ?>>Pengeluaran</option>
                                        <option value="pemasukan" <?php echo ($see['jenis'] == 'pemasukan') ? 'selected' : ''; ?>>Pemasukan</option>
                                    </select>
                                </div>
                            </div>

                            <!-- Grid Row for Tanggal & Semester -->
                            <div class="row">
                                <!-- Tanggal -->
                                <div class="col-md-6 mb-3">
                                    <label for="tanggal">Tanggal</label>
                                    <input type="date" name="tanggal" id="tanggal" value="<?php echo $see['tanggal']; ?>" class="form-control" required>
                                </div>

                                <!-- Semester -->
                                <div class="col-md-6 mb-3">
                                    <label for="id_semester">Semester</label>
                                    <select name="id_semester" id="id_semester" class="form-control" required>
                                        <option value="">Pilih Semester</option>
                                        <?php
                                        // Ambil semua kategori dari database
                                        $query_semester = "SELECT * FROM semester";
                                        $result_semester = mysqli_query($host, $query_semester);

                                        while ($semester = mysqli_fetch_assoc($result_semester)) {
                                            $selected = ($see['id_semester'] == $semester['id_semester']) ? 'selected' : '';
                                            echo "<option value='{$semester['id_semester']}' $selected>{$semester['semester']}</option>";
                                        }
                                        ?>
                                    </select>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <!-- Keperluan -->
                                    <label>Keperluan</label><br>
                                    <input type="text" name="keperluan" value="<?php echo $see['keperluan']; ?>" class="form-control" required> <br>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <!-- Nominal -->
                                    <div class="mb-3">
                                        <label for="nominal">Nominal</label>
                                        <input type="number" name="nominal" id="nominal" value="<?php echo $see['nominal']; ?>" class="form-control" required>
                                    </div>
                                </div>
                            </div>
                            

                            <!-- Foto Bukti -->
                            <div class="mb-3">
                                <label>Foto Bukti</label><br>
                                <?php if (!empty($see['bukti'])): ?>
                                    <!-- Tampilkan foto bukti yang ada -->
                                    <img src="../../../assets/uploads/bukti/<?php echo $see['bukti']; ?>" alt="Foto Bukti" width="100" height="auto" onclick="openModal('<?php echo '../../../assets/uploads/bukti/' . $see['bukti']; ?>')">
                                <?php else: ?>
                                    <p>Tidak ada foto bukti sebelumnya.</p>
                                <?php endif; ?>

                                <!-- Unggah Foto Baru -->
                                <label for="bukti">Unggah Foto Baru (Opsional)</label><br>
                                <input type="file" name="bukti" id="bukti" class="form-control" onchange="previewImage(event)">
                            </div>

                            <!-- Tempat Preview Foto Baru -->
                            <img id="preview" src="#" alt="Preview Foto" style="display:none; width:100px; height:auto; margin-top:10px;">

                            <!-- Catatan -->
                            <div class="mb-3">
                                <label for="catatan">Catatan</label><br>
                                <textarea name="catatan" id="catatan" rows="4" class="form-control"><?php echo $see['catatan']; ?></textarea>
                            </div>

                            <!-- Submit Button -->
                            <button class="btn btn-primary" name="update">Update</button>
                            <a href="data.php" class="btn btn-link">Kembali</a>

                             <!-- header("location:../views/flow/arus-per-semester.php?id_semester=" . $id_semester); -->

                        </form>

                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal untuk menampilkan foto bukti -->
    <div id="myModal" class="modal">
        <span class="close" onclick="closeModal()">&times;</span>
        <img class="modal-content" id="img01">
    </div>

    <script>
        // Fungsi untuk membuka modal dan menampilkan gambar
        function openModal(imageSrc) {
            var modal = document.getElementById("myModal");
            var img = document.getElementById("img01");
            modal.style.display = "block";
            img.src = imageSrc;
        }

        // Fungsi untuk menutup modal
        function closeModal() {
            var modal = document.getElementById("myModal");
            modal.style.display = "none";
        }

        // Fungsi untuk preview gambar baru yang diunggah
        function previewImage(event) {
            var reader = new FileReader();
            reader.onload = function() {
                var output = document.getElementById("preview");
                output.src = reader.result;
                output.style.display = "block";
            }
            reader.readAsDataURL(event.target.files[0]);
        }
    </script>

</body>
<?php include('../../../assets/template/footer.php'); ?>
