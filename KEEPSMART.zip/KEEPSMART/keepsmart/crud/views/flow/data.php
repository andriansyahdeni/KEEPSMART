<?php include('../../../assets/template/header.php'); ?>
<?php include('../../../koneksi.php'); ?>

<?php
// session_start();
if (isset($_SESSION['status'])) {
    $status = $_SESSION['status'];
    echo "<div class='alert alert-{$status['type']}'>{$status['message']}</div>";
    unset($_SESSION['status']); // Hapus setelah ditampilkan
}
?>


<style>
    .judul-container {
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    .judul-container h2 {
        margin: 0;
    }

    .semester-card {
        transition: transform 0.2s, box-shadow 0.2s;
        text-decoration: none;
        color: inherit;
    }

    .semester-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 6px 12px rgba(0, 0, 0, 0.2);
    }

    .semester-card .card-title {
        font-size: 1.5rem;
        font-weight: bold;
    }

    .semester-card .card-body {
        text-align: center;
        padding: 20px;
    }
</style>

<div class="container-fluid mt-5">
    <div class="judul-container mt-2 mb-4">
        <h2>Data Arus Uang per Semester</h2>
    </div>

    <!-- Grid Kartu Semester -->
    <div class="row g-3">
        <?php
        // Daftar warna soft yang acak
        $colors = [
            'rgba(255, 159, 64, 0.3)',  // Soft Orange
            'rgba(54, 162, 235, 0.3)',  // Soft Blue
            'rgba(75, 192, 192, 0.3)',  // Soft Teal
            'rgba(153, 102, 255, 0.3)', // Soft Purple
            'rgba(255, 99, 132, 0.3)',  // Soft Red
            'rgba(255, 205, 86, 0.3)'   // Soft Yellow
        ];

        // Misalnya id_user sudah tersedia dalam sesi atau sebagai parameter GET
        $id_user = $_SESSION['id_user']; // Atau $id_user = $_GET['id_user'] jika id_user dikirim via URL

        // Query untuk mendapatkan daftar semester
        $query = "SELECT DISTINCT id_semester, semester FROM semester ORDER BY semester ASC";
        $jalankan = mysqli_query($host, $query);

        if (mysqli_num_rows($jalankan) > 0) {
            while ($data = mysqli_fetch_assoc($jalankan)) {
                $id_semester = $data['id_semester'];
                $semester = $data['semester'];

                // Hitung Total Pemasukan berdasarkan id_user
                $query_pemasukan = "SELECT SUM(nominal) AS total_pemasukan FROM arus_uang WHERE id_semester = $id_semester AND jenis = 'Pemasukan' AND id_user = $id_user";
                $result_pemasukan = mysqli_query($host, $query_pemasukan);
                $total_pemasukan = mysqli_fetch_assoc($result_pemasukan)['total_pemasukan'] ?? null;

                // Hitung Total Pengeluaran berdasarkan id_user
                $query_pengeluaran = "SELECT SUM(nominal) AS total_pengeluaran FROM arus_uang WHERE id_semester = $id_semester AND jenis = 'Pengeluaran' AND id_user = $id_user";
                $result_pengeluaran = mysqli_query($host, $query_pengeluaran);
                $total_pengeluaran = mysqli_fetch_assoc($result_pengeluaran)['total_pengeluaran'] ?? null;

                // Hitung Sisa Saldo
                $sisa_saldo = isset($total_pemasukan, $total_pengeluaran) ? $total_pemasukan - $total_pengeluaran : null;

                // Pilih warna acak dari array warna
                $random_color = $colors[array_rand($colors)];
        ?>
                <div class="col-md-3 col-sm-6">
                    <a href="arus-per-semester.php?id_semester=<?= $id_semester ?>" class="semester-card">
                        <div class="card shadow-sm" style="background-color: <?= $random_color ?>;">
                            <div class="card-body">
                                <h4 class="card-title">Semester <?= htmlspecialchars($semester) ?></h4>
                                <small class="text-start d-block mt-5">
                                    <b>Pengeluaran:</b> <?= $total_pengeluaran !== null ? 'Rp ' . number_format($total_pengeluaran, 0, ',', '.') : '-' ?><br>
                                    <b>Sisa Saldo:</b> <?= $sisa_saldo !== null ? 'Rp ' . number_format($sisa_saldo, 0, ',', '.') : '-' ?>
                                </small>
                            </div>
                        </div>
                    </a>
                </div>
        <?php
            }
        } else {
            echo '<div class="col-12 text-center text-muted">Belum ada data kas yang tersedia.</div>';
        }
        ?>

<?php include('../../../assets/template/footer.php'); ?>