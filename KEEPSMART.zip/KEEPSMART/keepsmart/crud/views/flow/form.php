<?php
include('../../../assets/template/header.php'); 
// session_start();
if (!isset($_SESSION['id_user'])) {
    header("Location: ../authentication/login.php"); // Redirect ke halaman login jika belum login
    exit;
}
?>
<br>

<body class="body">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-11">
                <div class="card shadow">
                    <div class="card-body">
                        <h3 class="card-title text-center">Tambah Arus Uang</h3>
                        <hr>

                        <form action="../../controller/Flow.php" method="POST" enctype="multipart/form-data">
                            <!-- ID User -->
                            <input type="hidden" name="id_user" value="<?php echo $_SESSION['id_user']; ?>" required>

                            <!-- Grid Row for Kategori & Jenis -->
                            <div class="row">
                                <!-- Kategori -->
                                <div class="col-md-6 mb-3">
                                    <label for="id_kategori">Kategori</label>
                                    <select name="id_kategori" id="id_kategori" class="form-control" required>
                                        <option value="" disabled>Pilih Kategori</option>
                                        <?php
                                        include '../../../koneksi.php';
                                        $id_semester = isset($_GET['id_semester']) ? intval($_GET['id_semester']) : null;
                                        $query = "SELECT * FROM kategori WHERE id_user = '{$_SESSION['id_user']}'";
                                        $execute = mysqli_query($host, $query);

                                        while ($see = mysqli_fetch_assoc($execute)) {
                                            echo "<option value='{$see['id_kategori']}'>{$see['nama_kategori']}</option>";
                                        }
                                        ?>
                                    </select>
                                </div>

                                <!-- Jenis (masuk/keluar) -->
                                <div class="col-md-6 mb-3">
                                    <label for="jenis">Jenis</label>
                                    <select name="jenis" id="jenis" class="form-control" required>
                                        <option value="pengeluaran" selected>Pengeluaran</option>
                                        <option value="pemasukan">Pemasukan</option>
                                    </select>
                                </div>
                            </div>

                            <!-- Grid Row for Tanggal & Semester -->
                            <div class="row">
                                <!-- Tanggal -->
                                <div class="col-md-6 mb-3">
                                    <label for="tanggal">Tanggal</label>
                                    <input type="date" name="tanggal" id="tanggal" value="<?php echo date('Y-m-d'); ?>" class="form-control" required>
                                </div>

                                <!-- Semester -->
                                <div class="col-md-6 mb-3">
                                    <label for="id_semester">Semester</label>
                                    <?php
                                        // Query untuk mendapatkan nama semester berdasarkan id_semester
                                        if ($id_semester) {
                                            $semester_query = "SELECT semester FROM semester WHERE id_semester = '$id_semester'";
                                            $semester_result = mysqli_query($host, $semester_query);
                                            $semester = mysqli_fetch_assoc($semester_result);
                                            $semester_name = $semester ? $semester['semester'] : 'Semester Tidak Ditemukan';
                                        } else {
                                            $semester_name = 'Semester Tidak Ditemukan';
                                        }
                                    ?>
                                    <!-- Tampilkan nama semester di input teks -->
                                    <input type="text" class="form-control" value="<?= $semester_name ?>" readonly>

                                    <!-- Input hidden untuk mengirimkan id_semester -->
                                    <input type="hidden" name="id_semester" value="<?= $id_semester ?>">
                                </div>
                            </div>

                            <!-- Keperluan -->
                            <div class="mb-3">
                                <label for="keperluan">Keperluan</label><br>
                                <input type="text" name="keperluan" id="keperluan" class="form-control" required>
                            </div>

                            <!-- Nominal -->
                            <div class="mb-3">
                                <label for="nominal">Nominal</label><br>
                                <input type="number" name="nominal" id="nominal" class="form-control" required>
                            </div>

                            <!-- Bukti -->
                            <div class="mb-3">
                                <label for="bukti">Bukti (Opsional)</label><br>
                                <input type="file" name="bukti" id="bukti" class="form-control">
                            </div>

                            <!-- Catatan -->
                            <div class="mb-3">
                                <label for="catatan">Catatan</label><br>
                                <textarea name="catatan" id="catatan" rows="4" class="form-control"></textarea>
                            </div>

                            <br>

                            <!-- Submit Button -->
                            <button type="submit" name="tambah" class="btn btn-primary">Tambah</button>
                            <a href="data.php" class="btn btn-link">Kembali</a>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

</body>

<?php include('../../../assets/template/footer.php'); ?>
