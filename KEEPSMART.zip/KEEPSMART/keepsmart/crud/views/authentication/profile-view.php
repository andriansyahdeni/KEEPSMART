<?php include('../../../assets/template/header.php'); ?>

<?php
    include '../../../koneksi.php';
    // session_start();

    $id_user = $_SESSION['id_user'];

    // Query untuk mendapatkan data user berdasarkan id
    $query = "SELECT * FROM user WHERE id_user = $id_user";
    $execute = mysqli_query($host, $query);
    $user = mysqli_fetch_assoc($execute);
?>

<style>
    .judul-container {
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    .judul-container h2 {
        margin: 0;
    }

    .judul-container .btn {
        margin-left: 10px;
    }

    .form-label {
        font-weight: 500;
    }

    .img-thumbnail {
        max-width: 150px;
        cursor: pointer;
    }

    .modal-content {
        max-width: 100%;
        max-height: 80vh;
        margin: auto;
    }

    .modal {
        display: none;
        position: fixed;
        z-index: 1;
        left: 0;
        top: 0;
        width: 100%;
        height: 100%;
        overflow: auto;
        background-color: rgb(0,0,0);
        background-color: rgba(0,0,0,0.4);
        padding-top: 60px;
    }

    .close {
        position: absolute;
        top: 15px;
        right: 35px;
        color: #f1f1f1;
        font-size: 40px;
        font-weight: bold;
        transition: 0.3s;
    }

    .close:hover,
    .close:focus {
        color: #bbb;
        text-decoration: none;
        cursor: pointer;
    }

    .text-center img {
        max-width: 150px;
    }
</style>

<div class="container py-4">
    <!-- Judul dan Tombol Sejajar -->
    <div class="judul-container mb-3">
        <h2>Profil Saya</h2>
    </div>

    <div class="card shadow">
        <div class="card-body">
            <form action="../../controller/User.php?id_user=<?= $id_user ?>" method="POST" enctype="multipart/form-data">
                <div class="row g-3">
                    <div class="col-md-6">
                        <label for="username" class="form-label">Username</label>
                        <input type="text" id="username" name="username" class="form-control" value="<?= $user['username'] ?>" required>
                    </div>

                    <div class="col-md-6">
                        <label for="email" class="form-label">Email</label>
                        <input type="email" id="email" name="email" class="form-control" value="<?= $user['email'] ?>" required>
                    </div>
                </div>

                <div class="row g-3 mt-3">
                    <div class="col-md-6">
                        <label for="no_hp" class="form-label">No HP</label>
                        <input type="text" id="no_hp" name="no_hp" class="form-control" value="<?= $user['no_hp'] ?>" required>
                    </div>

                    <div class="col-md-6">
                        <label for="foto" class="form-label">Foto Profil</label>
                        <?php if (!empty($user['foto'])): ?>
                            <div class="text-center mb-3">
                                <img src="../../../assets/uploads/users/<?= $user['foto'] ?>" alt="Foto Profil" class="img-thumbnail" onclick="openModal('../../../assets/uploads/users/<?= $user['foto'] ?>')">
                            </div>
                        <?php else: ?>
                            <p class="text-muted">Tidak ada foto profil sebelumnya.</p>
                        <?php endif; ?>
                        <input type="file" name="foto" id="foto" class="form-control" onchange="previewImage(event)">
                    </div>
                </div>

                <div class="text-center mt-3">
                    <img id="preview" src="#" alt="Preview Foto" class="img-thumbnail" style="display:none;">
                </div>

                <div class="mt-4 text-center">
                    <button type="submit" name="update" class="btn btn-primary px-5">Perbarui Profil</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal untuk melihat foto lebih besar -->
<div id="myModal" class="modal">
    <span class="close" onclick="closeModal()">&times;</span>
    <img class="modal-content" id="img01">
</div>

<script>
    // Fungsi untuk membuka modal dan menampilkan gambar
    function openModal(imageSrc) {
        var modal = document.getElementById("myModal");
        var img = document.getElementById("img01");
        modal.style.display = "block";
        img.src = imageSrc;
    }

    // Fungsi untuk menutup modal
    function closeModal() {
        var modal = document.getElementById("myModal");
        modal.style.display = "none";
    }

    // Fungsi untuk preview gambar baru yang diunggah
    function previewImage(event) {
        var reader = new FileReader();
        reader.onload = function() {
            var output = document.getElementById('preview');
            output.src = reader.result;
            output.style.display = 'block';
        };
        reader.readAsDataURL(event.target.files[0]);
    }
</script>

<?php include('../../../assets/template/footer.php'); ?>
