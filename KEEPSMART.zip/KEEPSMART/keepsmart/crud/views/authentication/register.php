<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <!-- Link Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Link Google Font -->
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;700&display=swap" rel="stylesheet">
    <!-- Link Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <!-- SweetAlert2 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css" rel="stylesheet">
    <!-- SweetAlert2 JS -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.all.min.js"></script>

    <style>
        body {
            background: linear-gradient(to bottom, rgba(0, 123, 255, 0.3), rgba(0, 123, 255, 0.1)); /* Gradasi biru soft transparan */
            font-family: 'Plus Jakarta Sans', sans-serif;
        }

        .card {
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            background-color: #fff;
            position: relative; /* Untuk positioning tombol X */
        }
        .card .close-btn {
            position: absolute;
            top: 10px;
            right: 10px;
            background-color: #f1f1f1;
            border-radius: 50%;
            padding: 5px 10px;
            font-size: 18px;
            color: #333;
            cursor: pointer;
        }
        .card .close-btn:hover {
            background-color: #e0e0e0;
        }
        .btn-primary {
            background-color: #336699;
            border: none;
        }
        .btn-primary:hover {
            background-color: #264d73;
        }
        a {
            color: #336699;
        }
        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

<div class="container d-flex justify-content-center align-items-center vh-100">
    <div class="card p-4" style="max-width: 500px; width: 100%;">
        <!-- Tombol X untuk cancel -->
        <span class="close-btn" onclick="window.location.href='../../../index.php';">
            <i class="fas fa-times"></i>
        </span>
        
        <h2 class="text-center mb-4" style="font-weight: 800;">Sign Up</h2>
        <form action="../../controller/User.php" method="POST" enctype="multipart/form-data">
            <div class="row mb-3">
                <div class="col-md-6">
                    <label for="email" class="form-label">Email</label>
                    <input type="email" class="form-control" id="email" name="email" placeholder="Masukkan email" required>
                </div>
                <div class="col-md-6">
                    <label for="password" class="form-label">Password</label>
                    <input type="password" class="form-control" id="password" name="password" placeholder="Masukkan password" required>
                </div>
            </div>
            
            <div class="row mb-3">
                <div class="col-md-6">
                    <label for="username" class="form-label">Nama</label>
                    <input type="text" class="form-control" id="username" name="username" placeholder="Masukkan nama Anda" required>
                </div>
                <div class="col-md-6">
                    <label for="no_hp" class="form-label">No HP</label>
                    <input type="text" class="form-control" id="no_hp" name="no_hp" placeholder="Masukkan nomor HP" required>
                </div>
            </div>

            <div class="mb-3">
                <label for="foto" class="form-label">Foto Profil</label>
                <input type="file" class="form-control" id="foto" name="foto" required>
            </div>

            <button type="submit" name="register" class="btn btn-primary w-100">Sign Up</button>
            <p class="text-center mt-3">Sudah punya akun? <a href="login.php">Sign In</a></p>
        </form>
    </div>
</div>

<!-- Link Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
