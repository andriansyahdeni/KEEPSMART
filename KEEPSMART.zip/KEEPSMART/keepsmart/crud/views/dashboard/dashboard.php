<?php include('../../../assets/template/header.php'); ?>
<?php include('../../../koneksi.php'); ?>

<div class="title">
    <span class="text judul-container">Selamat Datang, <?php echo $_SESSION['username']; ?>!</span>
</div>

<div class="overview">
    <div class="title">
        <i class="fa-solid fa-gauge"></i>
        <span class="text">Dashboard</span>
    </div>

    <div class="boxes">
        <?php
        // Mendapatkan id_user dari sesi
        $id_user = $_SESSION['id_user'];

        // Query untuk mendapatkan total pemasukan berdasarkan id_user
        $query_pemasukan = "SELECT SUM(nominal) AS total_pemasukan FROM arus_uang WHERE jenis = 'Pemasukan' AND id_user = $id_user"; 
        $result_pemasukan = mysqli_query($host, $query_pemasukan);
        $total_pemasukan = mysqli_fetch_assoc($result_pemasukan)['total_pemasukan'] ?? 0; // Default 0 jika null

        // Query untuk mendapatkan total pengeluaran berdasarkan id_user
        $query_pengeluaran = "SELECT SUM(nominal) AS total_pengeluaran FROM arus_uang WHERE jenis = 'Pengeluaran' AND id_user = $id_user";
        $result_pengeluaran = mysqli_query($host, $query_pengeluaran);
        $total_pengeluaran = mysqli_fetch_assoc($result_pengeluaran)['total_pengeluaran'] ?? 0; // Default 0 jika null

        // Menghitung sisa saldo (pemasukan - pengeluaran)
        $sisa_saldo = $total_pemasukan - $total_pengeluaran;

        // Query untuk mendapatkan Uang Keluar berdasarkan id_user
        $query_uang_keluar = "SELECT SUM(nominal) AS total_keluar FROM arus_uang WHERE jenis = 'Pengeluaran' AND id_user = $id_user";
        $result_uang_keluar = mysqli_query($host, $query_uang_keluar);
        $uang_keluar = mysqli_fetch_assoc($result_uang_keluar)['total_keluar'] ?? 0; // Default 0 jika null

        // Query untuk mendapatkan Uang Masuk berdasarkan id_user
        $query_uang_masuk = "SELECT SUM(nominal) AS total_masuk FROM arus_uang WHERE jenis = 'Pemasukan' AND id_user = $id_user";
        $result_uang_masuk = mysqli_query($host, $query_uang_masuk);
        $uang_masuk = mysqli_fetch_assoc($result_uang_masuk)['total_masuk'] ?? 0; // Default 0 jika null
        ?>

        <div class="box box1">
            <i class="fa-solid fa-wallet"></i> <!-- Ikon untuk Saldo -->
            <span class="text">Sisa Saldo</span>
            <span class="number"><?php echo number_format($sisa_saldo, 0, ',', '.'); ?> IDR</span>
        </div>
        <div class="box box2">
            <i class="fa-solid fa-arrow-right-from-bracket"></i>
            <span class="text">Uang Keluar</span>
            <span class="number"><?php echo number_format($uang_keluar, 0, ',', '.'); ?> IDR</span>
        </div>
        <div class="box box3">
            <i class="fa-solid fa-arrow-right-to-bracket"></i>
            <span class="text">Uang Masuk</span>
            <span class="number"><?php echo number_format($uang_masuk, 0, ',', '.'); ?> IDR</span>
        </div>
    </div>
</div>

<?php include('../../../assets/template/footer.php'); ?> 
<script src="script.js"></script>
