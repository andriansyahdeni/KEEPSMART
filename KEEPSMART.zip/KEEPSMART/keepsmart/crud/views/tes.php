<?php include('../../assets/template/header.php'); ?>
            <div class="overview">
                <div class="title">
                    <i class="fa-solid fa-gauge"></i>
                    <span class="text">Dashboard</span>
                </div>

                <!-- <div class="boxes">
                    <div class="box box1">
                        <i class="fa fa-thumbs-up" aria-hidden="true"></i>
                        <span class="text">Total Likes</span>
                        <span class="number">50,120</span>
                    </div>
                    <div class="box box2">
                        <i class="fa-solid fa-comment"></i>
                        <span class="text">Comments</span>
                        <span class="number">20,120</span>
                    </div>
                    <div class="box box3">
                        <i class="fa-solid fa-share"></i>
                        <span class="text">Total Share</span>
                        <span class="number">10,120</span>
                    </div>
                </div> -->
            </div>
<?php include('../../assets/template/footer.php'); ?>
