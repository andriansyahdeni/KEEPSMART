<?php include('../../../assets/template/header.php'); ?>
<body class="body">

<div class="container mt-5">
    <h3 class="text-center">Laporan Keuangan</h3>
    <hr>

    <!-- Form Seleksi Data -->
    <form method="GET" id="form-filter">
        <div class="row">
            <!-- Filter Semester -->
            <div class="col-md-4">
                <label for="semester">Semester</label>
                <select name="id_semester" id="semester" class="form-control">
                    <option value="">Semua Semester</option>
                    <?php
                    include '../../../koneksi.php';
                    $query_semester = "SELECT * FROM semester";
                    $result_semester = mysqli_query($host, $query_semester);
                    while ($semester = mysqli_fetch_assoc($result_semester)) {
                        echo "<option value='{$semester['id_semester']}'>{$semester['semester']}</option>";
                    }
                    ?>
                </select>
            </div>

            <!-- Filter Kategori -->
            <div class="col-md-4">
                <label for="kategori">Kategori</label>
                <select name="id_kategori" id="kategori" class="form-control">
                    <option value="">Semua Kategori</option>
                    <?php
                    $query_kategori = "SELECT * FROM kategori WHERE id_user = '{$_SESSION['id_user']}'";
                    $result_kategori = mysqli_query($host, $query_kategori);
                    while ($kategori = mysqli_fetch_assoc($result_kategori)) {
                        echo "<option value='{$kategori['id_kategori']}'>{$kategori['nama_kategori']}</option>";
                    }
                    ?>
                </select>
            </div>

            <!-- Rentang Tanggal -->
            <div class="col-md-4">
                <label for="tanggal_mulai">Dari Tanggal</label>
                <input type="date" name="tanggal_mulai" id="tanggal_mulai" class="form-control">
                <label for="tanggal_selesai" class="mt-2">Sampai Tanggal</label>
                <input type="date" name="tanggal_selesai" id="tanggal_selesai" class="form-control">
            </div>
        </div>

        <!-- Tombol Lihat Data -->
        <div class="text-center mt-4">
            <button type="button" id="btn-filter" class="btn btn-primary">Lihat Data</button>
        </div>
    </form>

    <!-- Hasil Data -->
    <div id="data-laporan" class="mt-5">
        <!-- Data akan muncul di sini -->
    </div>
</div>

<!-- Script untuk Proses Filter -->
<script>
document.getElementById('btn-filter').addEventListener('click', function () {
    const form = document.getElementById('form-filter');
    const formData = new FormData(form);
    fetch('filter_data.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.text())
    .then(data => {
        document.getElementById('data-laporan').innerHTML = data;
    });
});
</script>

</body>
<?php include('../../../assets/template/footer.php'); ?>
