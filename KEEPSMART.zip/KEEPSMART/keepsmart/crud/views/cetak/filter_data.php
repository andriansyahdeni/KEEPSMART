<?php

session_start(); // Menjalankan sesi
include '../../../koneksi.php';

$id_semester = $_POST['id_semester'] ?? null;
$id_kategori = $_POST['id_kategori'] ?? null;
$tanggal_mulai = $_POST['tanggal_mulai'] ?? null;
$tanggal_selesai = $_POST['tanggal_selesai'] ?? null;

$query = "SELECT * FROM arus_uang WHERE id_user = '{$_SESSION['id_user']}'";
if ($id_semester) $query .= " AND id_semester = '$id_semester'";
if ($id_kategori) $query .= " AND id_kategori = '$id_kategori'";
if ($tanggal_mulai && $tanggal_selesai) $query .= " AND tanggal BETWEEN '$tanggal_mulai' AND '$tanggal_selesai'";

$result = mysqli_query($host, $query);
?>

<table class="table table-bordered">
    <thead>
        <tr class="tabel-primary">
            <th>No</th>
            <th>Tanggal</th>
            <th>Keperluan</th>
            <th>Jenis</th>
            <th>Nominal</th>
            <th>Kategori</th>
        </tr>
    </thead>
    <tbody>
        <?php
        $no = 1;
        while ($row = mysqli_fetch_assoc($result)) {
            $kategori_query = "SELECT nama_kategori FROM kategori WHERE id_kategori = '{$row['id_kategori']}'";
            $kategori_result = mysqli_fetch_assoc(mysqli_query($host, $kategori_query));
            $kategori_nama = $kategori_result['nama_kategori'] ?? '-';

            echo "<tr>
                <td>$no</td>
                <td>{$row['tanggal']}</td>
                <td>{$row['keperluan']}</td>
                <td>{$row['jenis']}</td>
                <td>Rp " . number_format($row['nominal'], 0, ',', '.') . "</td>
                <td>$kategori_nama</td>
              </tr>";
            $no++;
        }
        ?>
    </tbody>
</table>

<a href="cetak_laporan.php?id_semester=<?= $id_semester ?>&id_kategori=<?= $id_kategori ?>&tanggal_mulai=<?= $tanggal_mulai ?>&tanggal_selesai=<?= $tanggal_selesai ?>" target="_blank" class="btn btn-success">Cetak Laporan</a>
