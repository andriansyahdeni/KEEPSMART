<?php
include '../../../koneksi.php';
session_start();

$id_semester = $_GET['id_semester'] ?? null;
$id_kategori = $_GET['id_kategori'] ?? null;
$tanggal_mulai = $_GET['tanggal_mulai'] ?? null;
$tanggal_selesai = $_GET['tanggal_selesai'] ?? null;

// Format dates if they are provided
if ($tanggal_mulai) {
    $tanggal_mulai_terformat = date("d F Y", strtotime($tanggal_mulai));
} else {
    $tanggal_mulai_terformat = null;
}

if ($tanggal_selesai) {
    $tanggal_selesai_terformat = date("d F Y", strtotime($tanggal_selesai));
} else {
    $tanggal_selesai_terformat = null;
}

// Query to get semester name if id_semester is provided
$semester_name = '';
if ($id_semester) {
    $semester_query = "SELECT semester FROM semester WHERE id_semester = '$id_semester'";
    $semester_result = mysqli_query($host, $semester_query);
    if ($semester_row = mysqli_fetch_assoc($semester_result)) {
        $semester_name = $semester_row['semester'];
    }
}

$query = "SELECT * FROM arus_uang WHERE id_user = '{$_SESSION['id_user']}'";
if ($id_semester) $query .= " AND id_semester = '$id_semester'";
if ($id_kategori) $query .= " AND id_kategori = '$id_kategori'";
if ($tanggal_mulai && $tanggal_selesai) $query .= " AND tanggal BETWEEN '$tanggal_mulai' AND '$tanggal_selesai'";

$result = mysqli_query($host, $query);

// Informasi Judul
$judul = "Laporan Keuangan";
if ($id_semester && $semester_name) $judul .= " Semester $semester_name"; // Use the semester name
if ($tanggal_mulai && $tanggal_selesai) $judul .= " dari $tanggal_mulai_terformat sampai $tanggal_selesai_terformat";

$tanggal_terformat = date("d F Y"); // Format tanggal saat ini
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $judul ?></title>
    <style>
        body { font-family: Arial, sans-serif; }
        .container { width: 80%; margin: auto; }
        h3 { text-align: center; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        table, th, td { border: 1px solid black; }
        th, td { padding: 8px; text-align: center; }
    </style>
</head>
<body>
    <div class="container">
        <h3><?= $judul ?></h3>
        <p><strong>Nama User:</strong> <?= $_SESSION['username'] ?></p>
        <p><strong>Tanggal Cetak:</strong> <?= $tanggal_terformat?></p>

        <table>
            <thead>
                <tr>
                    <th>No</th>
                    <th>Tanggal</th>
                    <th>Keperluan</th>
                    <th>Jenis</th>
                    <th>Nominal</th>
                    <th>Kategori</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $no = 1;
                while ($row = mysqli_fetch_assoc($result)) {
                    $kategori_query = "SELECT nama_kategori FROM kategori WHERE id_kategori = '{$row['id_kategori']}'";
                    $kategori_result = mysqli_fetch_assoc(mysqli_query($host, $kategori_query));
                    $kategori_nama = $kategori_result['nama_kategori'] ?? '-';

                    echo "<tr>
                        <td>$no</td>
                        <td>" . date("d F Y", strtotime($row['tanggal'])) . "</td> <!-- Format Tanggal -->
                        <td>{$row['keperluan']}</td>
                        <td>{$row['jenis']}</td>
                        <td>Rp " . number_format($row['nominal'], 0, ',', '.') . "</td>
                        <td>$kategori_nama</td>
                      </tr>";
                    $no++;
                }
                ?>
            </tbody>
        </table>
    </div>

    <script>
        // Automatically trigger the print dialog when the page is loaded
        window.onload = function() {
            window.print();
        };
    </script>
    
</body>
</html>
