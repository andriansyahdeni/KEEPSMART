<?php
session_start();
include '../../koneksi.php';

// Pastikan user sudah login
if (!isset($_SESSION['id_user'])) {
    die("User not logged in");
}

$id_user = $_SESSION['id_user'];  // Ambil id_user dari session
$query = isset($_GET['query']) ? $_GET['query'] : '';

// Cari data berdasarkan query dan id_user di beberapa tabel
if ($query != '') {
    $stmt = $pdo->prepare(
        "SELECT 'kategori' AS source, id_kategori AS id, nama_kategori AS name 
         FROM kategori WHERE nama_kategori LIKE :query
         UNION
         SELECT 'semester' AS source, id_semester AS id, nama_semester AS name 
         FROM semester WHERE nama_semester LIKE :query
         UNION
         SELECT 'arus_uang' AS source, id_arus AS id, jenis, keperluan, nominal, tanggal, bukti, catatan 
         FROM arus_uang 
         WHERE (jenis LIKE :query OR keperluan LIKE :query OR nominal LIKE :query OR tanggal LIKE :query OR catatan LIKE :query) 
         AND id_user = :id_user"
    );
    $stmt->execute(['query' => "%$query%", 'id_user' => $id_user]);

    // Tampilkan hasil pencarian
    if ($stmt->rowCount() > 0) {
        while ($row = $stmt->fetch()) {
            // Tampilkan hasil sesuai source tabel
            if ($row['source'] == 'kategori') {
                echo "<div><strong>Kategori:</strong> " . htmlspecialchars($row['name']) . "</div>";
            } elseif ($row['source'] == 'semester') {
                echo "<div><strong>Semester:</strong> " . htmlspecialchars($row['name']) . "</div>";
            } elseif ($row['source'] == 'arus_uang') {
                echo "<div><strong>Jenis:</strong> " . htmlspecialchars($row['jenis']) . "<br>
                          <strong>Keperluan:</strong> " . htmlspecialchars($row['keperluan']) . "<br>
                          <strong>Nominal:</strong> " . htmlspecialchars($row['nominal']) . "<br>
                          <strong>Tanggal:</strong> " . htmlspecialchars($row['tanggal']) . "<br>
                          <strong>Bukti:</strong> " . htmlspecialchars($row['bukti']) . "<br>
                          <strong>Catatan:</strong> " . htmlspecialchars($row['catatan']) . "</div>";
            }
        }
    } else {
        echo "No results found.";
    }
}
?>
