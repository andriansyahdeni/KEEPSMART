<?php
include '../../koneksi.php';

// Mengatur direktori upload
$uploadDir = "../../assets/uploads/bukti/";
$allowedExts = array("gif", "jpeg", "jpg", "png");

// Fungsi untuk menangani upload file
function uploadFile($file) {
    global $uploadDir, $allowedExts;

    // Ekstensi file
    $temp = explode(".", $file['name']);
    $extension = end($temp);

    // Validasi file
    if ((in_array($extension, $allowedExts)) && ($file['size'] < 2000000) && 
        ($file['error'] == 0)) {
        
        // Nama file unik
        $newFileName = uniqid() . "." . $extension;

        // Periksa apakah file sudah ada
        if (!file_exists($uploadDir . $newFileName)) {
            // Pindahkan file ke direktori upload
            if (move_uploaded_file($file['tmp_name'], $uploadDir . $newFileName)) {
                return $newFileName; // Kembalikan nama file baru
            } else {
                return false; // Gagal memindahkan file
            }
        } else {
            return false; // File sudah ada
        }
    } else {
        return false; // File tidak valid
    }
}

// Fungsi untuk menghapus file
function deleteFile($fileName) {
    global $uploadDir;

    $filePath = $uploadDir . $fileName;
    if (file_exists($filePath)) {
        unlink($filePath); // Hapus file
    }
}

// INSERT - Menambahkan data
if (isset($_POST['tambah'])) {
    $id_user     = $_POST['id_user'];
    $id_kategori = $_POST['id_kategori'];
    $id_semester = $_POST['id_semester'];
    $jenis       = $_POST['jenis'];
    $keperluan   = $_POST['keperluan'];
    $tanggal     = $_POST['tanggal'];
    $nominal     = $_POST['nominal'];
    $catatan     = $_POST['catatan'];

    // Upload file dan dapatkan nama file
    $bukti = uploadFile($_FILES['bukti']);

    if ($bukti) {
        $query = "INSERT INTO arus_uang (id_user, id_kategori, id_semester, jenis, keperluan, tanggal, nominal, bukti, catatan) 
                  VALUES ('$id_user', '$id_kategori','$id_semester', '$jenis', '$keperluan', '$tanggal', '$nominal', '$bukti', '$catatan')";
        $execute = mysqli_query($host, $query);

        if ($execute) {
            header("location:../views/flow/arus-per-semester.php?id_semester=" . $id_semester);
        } else {
            header("location:../views/flow/form.php");
        }
    } else {
        echo "Upload failed or invalid file.";
    }
}

// UPDATE - Mengubah data
if (isset($_POST['update'])) {
    $id_arus    = $_GET['id_arus'];
    $id_user    = $_POST['id_user'];
    $id_kategori = $_POST['id_kategori'];
    $id_semester = $_POST['id_semester'];
    $jenis       = $_POST['jenis'];
    $keperluan   = $_POST['keperluan'];
    $tanggal     = $_POST['tanggal'];
    $nominal     = $_POST['nominal'];
    $catatan     = $_POST['catatan'];

    // Ambil bukti lama dari database
    $query = "SELECT bukti FROM arus_uang WHERE id_arus = '$id_arus'";
    $result = mysqli_query($host, $query);
    $row = mysqli_fetch_assoc($result);
    $bukti_lama = $row['bukti'];

    // Cek apakah ada file yang diupload
    if ($_FILES['bukti']['name'] != "") {
        // Upload file baru
        $bukti = uploadFile($_FILES['bukti']);

        if ($bukti) {
            // Hapus file lama jika ada file baru
            deleteFile($bukti_lama);
        } else {
            echo "Upload gagal";
            exit;
        }
    } else {
        // Jika tidak ada file baru, gunakan file lama
        $bukti = $bukti_lama;
    }

    // Update query
    $query = "UPDATE arus_uang SET 
                id_user       = '$id_user',
                id_kategori   = '$id_kategori',
                id_semester   = '$id_semester',
                jenis         = '$jenis',
                keperluan     = '$keperluan',
                tanggal       = '$tanggal',
                nominal       = '$nominal',
                bukti         = '$bukti',
                catatan       = '$catatan'
              WHERE id_arus = '$id_arus'";

    $execute = mysqli_query($host, $query);

    if ($execute) {
        header("location:../views/flow/form-edit.php?id_arus=$id_arus");
    } else {
        header("location:../views/flow/form-edit.php?id_arus=$id_arus");
    }
}

// DELETE - Menghapus data
if (isset($_GET['delete'])) {
    $id_arus = $_GET['delete'];

    // Ambil semester terkait dari database berdasarkan id_arus
    $query = "SELECT id_semester, bukti FROM arus_uang WHERE id_arus = '$id_arus'";
    $result = mysqli_query($host, $query);

    if ($result && mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
        $id_semester = $row['id_semester'];
        $fileToDelete = $row['bukti'];

        // Proses penghapusan data
        $query = "DELETE FROM arus_uang WHERE id_arus = '$id_arus'";
        $execute = mysqli_query($host, $query);

        if ($execute) {
            // Hapus file terkait jika penghapusan data berhasil
            deleteFile($fileToDelete);
            $_SESSION['status'] = ['type' => 'success', 'message' => 'Data berhasil dihapus!'];
        } else {
            $_SESSION['status'] = ['type' => 'error', 'message' => 'Gagal menghapus data.'];
        }
    } else {
        $_SESSION['status'] = ['type' => 'error', 'message' => 'Data tidak ditemukan.'];
    }

    // Redirect ke halaman rekap arus uang berdasarkan semester yang terkait
    header("location:../views/flow/arus-per-semester.php?id_semester=" . $id_semester);
    exit(); // Make sure to exit after the redirect to prevent further code execution
}

?>
