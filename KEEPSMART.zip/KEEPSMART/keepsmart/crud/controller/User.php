<?php
include '../../koneksi.php';

// Fungsi untuk mengunggah file
function uploadFile($file) {
    $uploadDir = "../../assets/uploads/users/";
    $allowedExts = array("gif", "jpeg", "jpg", "png");

    $temp = explode(".", $file['name']);
    $extension = end($temp);

    if ((in_array($extension, $allowedExts)) && ($file['size'] < 2000000) && ($file['error'] == 0)) {
        $newFileName = uniqid() . "." . $extension;
        if (!file_exists($uploadDir . $newFileName)) {
            if (move_uploaded_file($file['tmp_name'], $uploadDir . $newFileName)) {
                return $newFileName;
            }
        }
    }
    return false;
}

//REGISTER - melakukan pendaftaran akun
if (isset($_POST['register'])) {
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT);
    $no_hp = $_POST['no_hp'];
    $foto = uploadFile($_FILES['foto']); // Menggunakan fungsi upload

    if ($foto) {
        $query = "INSERT INTO user (username, email, password, no_hp, foto) VALUES ('$username', '$email', '$password', '$no_hp', '$foto')";
        if (mysqli_query($host, $query)) {
            $id_user = mysqli_insert_id($host);

            $defaultCategory = "Pendidikan";
            $categoryQuery = "INSERT INTO kategori (id_user, nama_kategori) VALUES ('$id_user', '$defaultCategory')";

            if (mysqli_query($host, $categoryQuery)) {
                echo "
                    <script src='https://cdn.jsdelivr.net/npm/sweetalert2@11'></script>
                    <script>
                        document.addEventListener('DOMContentLoaded', function() {
                            Swal.fire({
                                title: 'Registrasi Berhasil!',
                                text: 'Akun Anda telah dibuat. Silakan login untuk melanjutkan.',
                                icon: 'success',
                                confirmButtonText: 'OK'
                            }).then(() => {
                                window.location.href = '../views/authentication/login.php';
                            });
                        });
                    </script>
                ";
            } else {
                echo "
                    <script src='https://cdn.jsdelivr.net/npm/sweetalert2@11'></script>
                    <script>
                        Swal.fire({
                            title: 'Gagal Menambahkan Kategori!',
                            text: '" . mysqli_error($host) . "',
                            icon: 'error',
                            confirmButtonText: 'Coba Lagi'
                        });
                    </script>
                ";
            }
        } else {
            echo "
                <script src='https://cdn.jsdelivr.net/npm/sweetalert2@11'></script>
                <script>
                    Swal.fire({
                        title: 'Registrasi Gagal!',
                        text: '" . mysqli_error($host) . "',
                        icon: 'error',
                        confirmButtonText: 'Coba Lagi'
                    });
                </script>
            ";
        }
    } else {
        echo "
            <script src='https://cdn.jsdelivr.net/npm/sweetalert2@11'></script>
            <script>
                Swal.fire({
                    title: 'Gagal Mengunggah Foto!',
                    text: 'File foto tidak valid atau terlalu besar.',
                    icon: 'error',
                    confirmButtonText: 'Coba Lagi'
                });
            </script>
        ";
    }
}

//UPDATE AND VIEW - untuk preview akun (seperti di halaman arus kas)
if (isset($_POST['update'])) {
    $id_user = $_GET['id_user'];
    $username = $_POST['username'];
    $email = $_POST['email'];
    $no_hp = $_POST['no_hp'];

    // Periksa apakah ada file baru yang diunggah
    if (!empty($_FILES['foto']['name'])) {
        $foto = uploadFile($_FILES['foto']); // Mengunggah foto baru
        if ($foto) {
            $query = "UPDATE user SET username='$username', email='$email', no_hp='$no_hp', foto='$foto' WHERE id_user=$id_user";
        } else {
            echo "Gagal mengunggah foto.";
        }
    } else {
        // Jika tidak ada foto baru
        $query = "UPDATE user SET username='$username', email='$email', no_hp='$no_hp' WHERE id_user=$id_user";
    }

    if (mysqli_query($host, $query)) {
        header("Location: ../../crud/views/dashboard/profile.php?id_user=$id_user");
        exit();
    } else {
        echo "Gagal memperbarui profil. " . mysqli_error($host);
    }
}
?>