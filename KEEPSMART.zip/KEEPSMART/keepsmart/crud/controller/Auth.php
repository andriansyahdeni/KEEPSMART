<?php
session_start();
include '../../koneksi.php';

if (isset($_POST['login'])) {
    $email = $_POST['email'];
    $password = $_POST['password'];

    $query = "SELECT * FROM user WHERE email = '$email'";
    $result = mysqli_query($host, $query);
    $user = mysqli_fetch_assoc($result);

    if ($user && password_verify($password, $user['password'])) {
        // Set session
        $_SESSION['id_user'] = $user['id_user'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['email'] = $user['email'];
        $_SESSION['foto'] = $user['foto'];

        header("Location:../views/dashboard/dashboard.php");
        exit;
    } else {
        $_SESSION['login_error'] = true;
        header("Location: ../views/authentication/login.php");
        exit;
    }
}
?>
