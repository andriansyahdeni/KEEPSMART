<?php
session_start();
session_destroy();
header("location:../views/authentication/login.php");
exit;
?>
