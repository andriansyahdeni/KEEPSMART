<?php
session_start();
if (isset($_SESSION['status'])) {
    $status = $_SESSION['status'];
    echo "<script>
        document.addEventListener('DOMContentLoaded', function() {
            Swal.fire({
                icon: '{$status['type']}',
                title: '{$status['message']}',
                showConfirmButton: false,
                timer: 1500
            });
        });
    </script>";
    unset($_SESSION['status']); // Hapus session setelah ditampilkan
}
?>    
    
    
    <?php

    include '../../koneksi.php';
    session_start();

    // Ambil id_user dari sesi
    $id_user = $_SESSION['id_user'];

    // INSERT - Menambahkan data
    if (isset($_POST['tambah'])) {
        $nama_kategori = $_POST['nama_kategori'];

        // Tambahkan kategori dengan id_user
        $perintah = "INSERT INTO kategori VALUES (NULL,'$id_user','$nama_kategori')";

        $execute = mysqli_query($host, $perintah);
        
        if ($execute) {
            $_SESSION['status'] = ['type' => 'success', 'message' => 'Data berhasil disimpan!'];
            header("location:../views/category/data.php");
        } else {
            $_SESSION['status'] = ['type' => 'error', 'message' => 'Gagal menyimpan data.'];
            header("location:../views/category/form.php");
        }
        
    }

    // UPDATE - Merubah data
    if (isset($_POST['update'])) {
        $id_kategori = $_GET['id_kategori'];
        $nama_kategori = $_POST['nama_kategori'];

        // Update kategori hanya jika milik pengguna yang login
        $query = "UPDATE kategori SET 
            nama_kategori = '$nama_kategori'
            WHERE id_kategori = $id_kategori AND id_user = '$id_user'";

        $execute = mysqli_query($host, $query);

        if ($execute) {
            $_SESSION['status'] = ['type' => 'success', 'message' => 'Data berhasil diperbarui!'];
            header("location:../views/category/data.php");
        } else {
            $_SESSION['status'] = ['type' => 'error', 'message' => 'Gagal memperbarui data.'];
            header("location:../views/category/form-edit.php?id=$id_kategori");
        }
        
    }

    // DELETE - Menghapus data
    if (isset($_GET['delete'])) {
        $id_kategori = $_GET['delete'];

        // Hapus kategori hanya jika milik pengguna yang login
        $query = "DELETE FROM kategori WHERE id_kategori = '$id_kategori' AND id_user = '$id_user'";
        $execute = mysqli_query($host, $query);

        if ($execute) {
            $_SESSION['status'] = ['type' => 'success', 'message' => 'Data berhasil dihapus!'];
        } else {
            $_SESSION['status'] = ['type' => 'error', 'message' => 'Gagal menghapus data.'];
        }
        header("location:../views/category/data.php");
        
    }
