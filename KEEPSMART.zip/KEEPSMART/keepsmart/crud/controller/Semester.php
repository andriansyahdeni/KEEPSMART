<?php

    include '../../koneksi.php';

    // INSERT - menambahkan data
    if (isset($_POST['tambah'])) {

        $semester       = $_POST['semester'];

        $perintah = "INSERT INTO semester VALUES(NULL, '$semester')";

        $execute  = mysqli_query($host, $perintah);

        if ($execute) {
            header("location:../views/semester/data.php");
            // header location digunakan untuk berpindah otomatis
        }else{
            header("location:../views/semester/form.php");
        }

    }


    // UPDATE - merubah data
    if (isset($_POST['update'])) {
        $id_semester  = $_GET['id_semester'];

        $semester       = $_POST['semester'];

        $query = "UPDATE semester SET 
            semester       = '$semester'
            WHERE id_semester = $id_semester";

        $execute = mysqli_query($host, $query);

        if ($execute) {
            header("location:../views/semester/data.php");
        }else{
            header("location:../views/semester/form-edit.php?id=$id");
        }
    }
    

    // DELETE - menghapus data
    if (isset($_GET['delete'])) {
        $id_semester = $_GET['delete'];

        $query   = "DELETE FROM semester WHERE id_semester = '$id_semester'";
        $execute = mysqli_query($host, $query);

        if ($execute) {
            header("location:../views/semester/data.php");
        }else{
            header("location:../views/semester/data.php");
        }
    }