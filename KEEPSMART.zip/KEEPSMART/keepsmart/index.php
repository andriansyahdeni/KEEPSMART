<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Index</title>

    <link rel="shortcut icon" href="assets/template/assets/transfer.png" type="image/x-icon">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <style>
        @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:ital,wght@0,200..800;1,200..800&family=Titan+One&display=swap');

        :root{
            --primary: #3155e7;
            --primary-dark: #2045d6;
            --black: #010101;
            --gray-1: #788190;
            --gray-2: #d3d4db;
            --white: #FFFFFF;
            --body: #fefefe;
        }

        body{
            font-family: 'Plus Jakarta Sans', sans-serif;
            background-color: var(--body);
        }

        /*komponen */
        .btn{
            border-radius: 8px;
        }

        .btn-primary,
        .btn-outline-secondary{
            padding: 12px 20px;
        }

        .btn-primary{
            background-color: var(--primary);
        }

        .btn-primary:hover{
            background-color: var(--primary-dark);
        }

        .btn-outline-secondary{
            border: 1px solid var(--gray-2);
            color: var(--black);
        }

        .btn-outline-secondary:hover{
            background-color: var(--gray-2);
            border: 1px solid var(--gray-2);
            color: var(--black);
        }

        .btn-outline-secondary:focus{
            background-color: var(--gray-2);
            border: 1px solid var(--gray-2);
            color: var(--black);
        }

        /* navbar */
        .navbar .btn-outline-secondary{
            border: 1px solid var(--gray-2);
            color: var(--black);
            font-size: 14px;
            font-weight: 500;
            line-height: 20px;
            padding: 10px 16px;
        }

        .navbar{
            padding: 32px 0;
        }

        .nav-link{
            margin-left: 41px;
            font-size: 16px;
            color: var(--gray-1);
        }

        .navbar-nav .nav-link.active{
            font-weight: bold;
            color: var(--black);
        }

        /* HERO */
        section.hero{
            padding: 80px 0;
        }

        section.hero .text{
            font-weight: 800;
            font-size: 48px;
            line-height: 73px;
            color: var(--black);
        }

        .buttons{
            padding-top: 69px;
        }

        .buttons .btn{
            font-size: 16px;
            font-weight: bold;
            line-height: 24px;
        }

        /* setup section */
        section.setup{
            padding: 287px 0; 
        }

        section.setup .text-header h3{
            font-size: 42px;
            font-weight: 700;
            line-height: 48px;
            color: var(--black);
        }

        section.setup .text-header p{
            font-size: 18px;
            font-weight: 400;
            line-height: 28px;
            color: var(--gray-1);
            padding: 27px 0;
        }

        section.setup .icons{
            padding: 27px 0;
        }

        section.setup h5{
            font-size: 18px;
            font-weight: 700;
            line-height: 24px;
            color: var(--black);
            padding-bottom: 18px;
        }

        section.setup .desc p{
            font-weight: 400;
            font-size: 13px;
            line-height: 22px;
            color: var(--gray-1);
            max-width: 284px;
            margin: 0 auto;
        }

        /* info section */
        section.information .text-information{
            padding: 134px 0;
        }

        section.information h5{
            font-size: 42px;
            font-weight: 700;
            line-height: 48px;
            color: var(--black);
        }

        section.information p{
            font-size: 18px;
            font-weight: 300;
            line-height: 28px;
            color: var(--gray-1);
            padding-top: 20px;
        }

        section.information .info-1{
            padding: 183px 0;
        }

        /* footer */
        /* footer{
            padding-bottom: 279px;
            margin-bottom: 44px;
        } */

        footer a{
            font-weight: bold;
            font-size: 14px;
            color: var(--black);
            line-height: 18px;
        }

        footer .copy{
            margin-top: 32px;
            font-size: 14px;
            color: var(--gray-1);
            line-height: 17px;
            font-weight: 400;
        }

        /* responsive section */
        @media (max-width: 576px) {
            /* General Text Alignment for Small Screens */
            section.hero,
            section.setup,
            section.information {
                text-align: center;
            }

            /* Navbar */
            .navbar {
                padding: 20px 0; 
            }

            .nav-link {
                margin-left: 0;
                font-size: 14px; /* Adjust font size for smaller screens */
            }

            /* Hero Section */
            section.hero img {
                padding-top: 2.5rem;
                max-width: 100%; /* Ensure image is responsive */
                height: auto; /* Maintain aspect ratio */
            }

            section.hero .text {
                font-weight: 800;
                font-size: 36px; /* Slightly smaller font size */
                line-height: 50px; /* Adjust line height */
            }

            .buttons .btn {
                display: block;
                margin: 1rem auto; /* Center buttons */
                width: 90%; /* Full width for buttons */
            }

            .buttons .ms-3 {
                margin-left: 0 !important;
            }

            /* Setup Section */
            section.setup {
                padding: 50px 15px; /* Adjust padding for smaller screens */
            }

            section.setup .text-header h3 {
                font-size: 32px; /* Smaller font size */
                line-height: 40px; /* Adjust line height */
            }

            section.setup .text-header p {
                font-size: 16px; /* Smaller font size */
                line-height: 24px; /* Adjust line height */
            }

            .buttons .btn{
                display: block;
                /* margin: 1rem 0; */
            }

            /* .buttons .ms-3{
                margin-left: 0 !important;
            } */

            /* Information Section */
            .info-1, .info-2 {
                flex-direction: column; /* Stack elements vertically */
            }

            /* Footer */
            footer {
                padding-top: 50px;
                text-align: center; /* Center footer text */
            }

            footer .copy {
                margin-top: 20px;
                font-size: 12px; /* Smaller font size */
            }

            footer a {
                display: block; /* Stack footer links */
                margin: 5px 0; /* Spacing between links */
            }
        }



    </style>
</head>
<body>
    <!-- navbar -->
    <nav class="navbar navbar-expand-lg navbar-light">
        <div class="container">
            <a class="navbar-brand" href="#">
                <!-- brand -->
                <img src="assets/template/assets/transfer.png" style="width: 40px;" alt="brand" srcset=""> <b style="font-weight: 800; font-size: 25px; margin-left:8px">KEEPSMART</b>
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
                <div class="navbar-nav ms-auto">
                    <a class="nav-link active" aria-current="page" href="#home">Home</a>
                    <a class="nav-link" href="#setup">About</a>
                    <a class="nav-link me-5" href="#info">Info</a>
                </div>
            <!-- <a href="" class="btn btn-outline-secondary shadow-sm d-sm d-block">LLLLL</a> -->
            </div>
        </div>
    </nav>

    <!-- HERO -->
    <section class="hero" id="hero">
        <div class="container">
            <div class="row">
                <!-- text -->
                <div class="col-md-6">
                    <div class="text">
                        Take Control of Your Scholarship Budget: Smart Choices, Bright Future! 
                    </div>
                    <div class="buttons">
                        <a href="crud/views/authentication/login.php" class="btn btn-primary">Sign In</a>
                        <a href="crud/views/authentication/register.php" class="btn btn-outline-secondary">Sign Up</a>
                    </div>
                </div>

                <!-- image -->
                <div class="col-md-6">
                <img src="assets/template/image/1.svg" alt="hero-img" class="img-fluid">
                </div>
            </div>
        </div>
    </section>

    <!-- setup section -->
    <section class="setup" id="setup">
        <div class="container">
            <div class="text-center text-header">
                <h3>Here’s Everything You Need to Know</h3>
                <p>KEEPSMART adalah platform yang dirancang untuk membantu mahasiswa penerima KIP-K (Kartu Indonesia Pintar - Kuliah) dalam mengelola dan mengatur keuangan beasiswa mereka. Website ini menyediakan fitur untuk memantau pengeluaran, merencanakan anggaran, dan memastikan dana beasiswa digunakan dengan bijak, sehingga mahasiswa dapat lebih fokus pada studi mereka.</p>
            </div>
            <div class="items text-center">
                <div class="row">
                    <div class="col-md-4">
                        <div class="icons">
                            <img src="assets/template/image/icons/icons-1.svg" alt="" srcset="">
                        </div>
                        <div class="desc">
                            <h5>Personal Use</h5>
                            <p>Website dirancang untuk penggunaan pribadi, memudahkan pengelolaan keuangan beasiswa dengan fitur yang disesuaikan untuk kebutuhan individu.</p>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="icons">
                            <img src="assets/template/image/icons/icons-2.svg" alt="" srcset="">
                        </div>
                        <div class="desc">
                            <h5>Manage Your Funds</h5>
                            <p>Kelola dana beasiswa dengan efisien, pantau pengeluaran, dan rencanakan anggaran untuk mendukung perjalanan pendidikan Anda.</p>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="icons">
                            <img src="assets/template/image/icons/icons-3.svg" alt="" srcset="">
                        </div>
                        <div class="desc">
                            <h5>Efficient & Accessible Anywhere</h5>
                            <p>Kelola keuangan beasiswa secara efisien dan akses platform ini kapan saja, di mana saja, untuk kenyamanan Anda.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- infomation -->
    <section class="information" id="info">
        <div class="container">
            <div class="row info-1">
                <!-- text -->
                <div class="col-md-6">
                    <div class="text-information">
                        <h5>Track Your Expenses</h5>
                        <p>Pantau kebiasaan pengeluaran Anda dan catat setiap pengeluaran dengan mudah. Tetap kontrol keuangan Anda!</p>
                    </div>
                </div>
                <!-- image -->
                <div class="col-md-6">
                    <img src="assets/template/image/image-1.svg" alt="" srcset="" class="w-100">
                </div>
            </div>
            <div class="row info-2">
                <!-- image -->
                <div class="col-md-6">
                    <img src="assets/template/image/image-2.svg" alt="" srcset="" class="w-100">
                </div>
                <!-- text -->
                <div class="col-md-6">
                    <div class="text-information">
                        <h5>Smart Financial Planning</h5>
                        <p>Rencanakan anggaran beasiswa Anda dengan bijak agar dana cukup untuk kebutuhan akademik dan sehari-hari.p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- footer -->
    <footer style="padding-top:279px; margin-bottom:44px;">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <div class="row row-cols-1 row-cols-lg-5 g-2 g-lg-3">
                        <div class="col-md-3">
                            <div class="">
                                <small>
                                    <a href="#hero" class="text-decoration-none">Home</a>
                                </small>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="">
                                <small>
                                    <a href="#setup" class="text-decoration-none">About</a>
                                </small>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="">
                                <small>
                                    <a href="#info" class="text-decoration-none">Info</a>
                                </small>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="copy">
                Created with ❤️ by Deni Andriansyah (2024)
                </div>
            </div>
        </div>
    </footer>






    <!-- <a href="crud/views/authentication/login.php">Login</a>
    <a href="crud/views/authentication/register.php">Register</a> -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
</body>
</html>